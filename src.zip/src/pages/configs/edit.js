import React from 'react';

const ConfigEdit = () => {
    return (
        <div>
            <h1>Config Edit</h1>
        </div>
    );
};

export default ConfigEdit;