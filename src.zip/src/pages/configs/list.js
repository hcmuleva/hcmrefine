import React from 'react';

function ConfigList(props) {
    return (
        <div>
            <h1>ConfigList</h1>
        </div>
    );
}

export default ConfigList;