import React from 'react';

const ConfigDetail = () => {
    return (
        <div>
            <h1>Config Details</h1>
        </div>
    );
};

export default ConfigDetail;