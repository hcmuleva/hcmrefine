import React from 'react';

const CreateConfig = () => {
    return (
        <div>
            <h1>CreateConfig</h1>
        </div>
    );
};

export default CreateConfig;