import { useShow, useOne } from "@refinedev/core";

import { Show, MarkdownField } from "@refinedev/antd";

import { Typography } from "antd";

const { Title, Text } = Typography;

export const ProjectShow = () => {
    const {queryResult} = useShow({
            resource: "projects",
        metaData: {
            populate: ["configs"]
        },
    })
    
    const {data,isLoading} = queryResult
    console.log("DATA ", data)
//     const { tableProps, filters } = useTable({
//         /**
//          * This will make our table sync with the URL.
//          *
//          * Syncing includes, sorters, filters and pagination. (Extra parameters are kept in the URL)
//          */
//         syncWithLocation: true,
//     });

//     const configIds =
//         tableProps?.dataSource?.map((item) => item.configs.id) ?? [];
//     const { data, isLoading } = useMany({
//         resource: "configs",
//         ids: categoryIds,
//         queryOptions: {
//             enabled: categoryIds.length > 0,
//         },
//     });

//     const { selectProps: categorySelectProps } = useSelect({
//         resource: "config",
//         optionLabel: "Titl",
//         optionValue: "id",
//         defaultValue: getDefaultFilter("config.id", filters, "in"),
//     });
// console.log("data",data)


    // const { queryResult } = useShow();
    // const { data, isLoading } = queryResult;
    // const record = data?.data;
    // if(isLoading){
    //   <h1>Loading</h1>
    // }
    // console.log("REcord in projectShow",data)

    // const projectid = record?.id
    // console.log("projectid", projectid)
    
    // const { data: projectdata, isLoading: projectIsLoading } = useOne({
    //     resource: "projects",
    //     metaData: {
    //         populate: ["configs"]
    //     },
        
    // });
    // const configdata = projectdata?.data?.configs ?? [];

    // console.log("configurationData", configdata)
// console.log("PRojectShow configdata", configdata)

    return (
        <h1>DDDD</h1>
        // <Show isLoading={isLoading}>
        //     <h1>{configurationData.data.name}</h1>

        //      <table>
        //         <thead>
        //             <tr>
        //                 <th>ID</th>
        //                 <th>Title</th>
        //                 <th>Status</th>
        //                 <th>Created At</th>
        //             </tr>
        //         </thead>
        //         <tbody>
        //             {configdata.map((conf) => (
        //                 <tr key={conf.id}>
        //                     <td>{conf.id}</td>
        //                     <td>{conf.name}</td>
        //                     <td>{post.status}</td>
        //                     <td>{new Date(post.createdAt).toDateString()}</td>
        //                 </tr>
        //             ))}
        //         </tbody>
        //     </table>
        //     </Show>

        //     <Title level={5}>Configuration</Title>
        //     <Text>
        //         {configurationIsLoading ? "Loading..." : configurationData?.data.title}
        //     </Text>

        //     <Title level={5}>Content</Title>
        //     <MarkdownField value={record?.content} />
        // </Show>
    );
};
