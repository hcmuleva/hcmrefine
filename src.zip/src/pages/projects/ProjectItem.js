import { DeleteButton,EditButton, ShowButton } from "@refinedev/antd";

import { EditOutlined } from "@ant-design/icons";
import { Card } from "antd";

import { API_URL } from "../../constants";



const { Meta } = Card;

export const ProjectItem = ({ item, imgurl }) => {
   
    console.log("ITEM recieved", item)
    const editProjectShow=(item)=>{
        console.log("Edit item clicked", item)
    }
    return (
        <Card
            style={{ width: 300 }}
             cover={<img alt="example" src={imgurl} height="240" />}
            actions={[
                <EditButton key="edit" recordItemId={item.id}/>,
                <DeleteButton
                    key="delete"
                    size="small"
                    hideText
                    recordItemId={item.id}
                />,
                <ShowButton  key="show"
                size="small"
                hideText
                recordItemId={item.id}/>
            ]}
        >
            <Meta
                className="ant-card-meta-title"
                title={item.name}
                description={item.description}
            />
        </Card>
    );
};
