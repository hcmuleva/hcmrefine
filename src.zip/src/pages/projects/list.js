import { useState } from "react";
import { List as AntdList } from "antd";
import {
    useDrawerForm,
    DateField, DeleteButton, EditButton, FilterDropdown, getDefaultSortOrder, ImageField, List, useSelect, useTable,ShowButton, CreateButton, useSimpleList
} from "@refinedev/antd";

import { Form, Radio, Select, Space, Table, Tag } from "antd";


import { API_URL } from "../../constants";
import { useList, useMany } from "@refinedev/core";
import { ProjectItem } from "./ProjectItem";




export const ProjectList = () => {
    // const { data, isLoading, isError } = useList({
    //     resource: "projects",
    //     metaData: { populate: ["configs"] },
    // });

    const { listProps } = useSimpleList({
        resource: "projects",
        metaData: { populate: ["configs"] },
    });
    const {
        drawerProps: createDrawerProps,
        formProps: createFormProps,
        saveButtonProps: createSaveButtonProps,
        show: createShow,
    } = useDrawerForm({
        action: "create",
        resource: "projects",
        redirect: true,
    });
    return(
        <>
        <List
            headerProps={{
                extra: <CreateButton onClick={() => createShow()} />,
            }}
        >
            <AntdList
                grid={{ gutter: 16, xs: 1 }}
                style={{
                    justifyContent: "center",
                }}
                {...listProps}
                renderItem={(item) => {
                    const imgurl = `https://loremflickr.com/640/480/animals?random=${Math.random()}`;
                    return <AntdList.Item>
                        <ProjectItem item={item} imgurl={imgurl} />
                    </AntdList.Item>
                }}
            />
        </List>
        {/* <EditProduct
            modalProps={editModalProps}
            formProps={editFormProps}
        />
        <CreateProduct
            drawerProps={createDrawerProps}
            formProps={createFormProps}
            saveButtonProps={createSaveButtonProps}
        /> */}
    </>
    );
};



